#!/bin/bash

while true
do
./wildrig-multi --print-full --algo ghostrider --url stratum+tcp://stratum-eu.rplant.xyz:7056 --user RH5T8FjmjmipeHjn4SGK9KqgvEuEwnj1Yg --pass x
sleep 5
done
