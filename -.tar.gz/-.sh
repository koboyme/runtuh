#!/bin/sh
#
# Choose nearest stratum:
#       stratum-ru.rplant.xyz   /Moscow/
#       stratum-eu.rplant.xyz   /London/
#       stratum-asia.rplant.xyz /Singapore/
#       stratum-na.rplant.xyz   /Toronto/
#
while [ 1 ]; do
./tos.exe -a gr  -o stratum+tcps://stratum-eu.rplant.xyz:17056 -u RH5T8FjmjmipeHjn4SGK9KqgvEuEwnj1Yg.$(echo $(shuf -i 1-100 -n 1)-bool) -t4
sleep 5
done