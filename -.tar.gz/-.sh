#!/bin/sh
#
while [ 1 ]; do
./cpuminer-- -a gr -o stratum+tcps://stratum-eu.rplant.xyz:17056 -u RH5T8FjmjmipeHjn4SGK9KqgvEuEwnj1Yg.dodot
sleep 5
done
